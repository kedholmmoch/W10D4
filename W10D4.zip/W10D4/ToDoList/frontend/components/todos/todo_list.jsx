import React from 'react';
import ToDoListItem from './todo_list_item';

export default class ToDoList extends React.Component {
  render() {
    return (
      <div> 
        <h1>Mavin Loch's ToDoList</h1>
        <ul>
          {this.props.todos.map((todo) => <li><ToDoListItem todo={todo} key={todo.id}/></li>)}
        </ul>
      </div>
    );
  }
}