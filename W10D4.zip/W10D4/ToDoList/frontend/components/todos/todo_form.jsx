import React from 'react';
import { uniqueId } from '../../util/util';

class ToDoForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      id: uniqueId(),
      title: "",
      body: "",
      done: false
    };
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit() {

  }

  handleTitle() {

  }

  handleBody() {

  }

  render() {
    return (
      <div>
        <h1>Add ToDo: </h1>
        <form onSubmit={this.handleSubmit}>
          <label>Title 
            <input type="text" onChange={this.handleTitle} value={this.state.title}/>
          </label>
        
          <label>Description 
            <input type="text" onChange={this.handleBody} value={this.state.body}/>
          </label>
        
        
        </form>
      </div>
    )
  }
}
