import { connect } from 'react-redux';
import ToDoList from './todo_list';
import { receiveTodo } from '../../actions/todo_actions';

const mapStateToProps = (state) => ({
  todos: Object.values(state.todos)
});

const mapDispatchToProps = (dispatch) => ({
  receiveTodo: (todo) => dispatch(receiveTodo(todo))
});


export default connect(mapStateToProps, mapDispatchToProps)(ToDoList);